# Generic Service
Generic Service component allows user to easily convert an existing model serving image into a Rampart Component.

## Usage
### Configuration options
> **Warning**
> Ingress **cannot** be enabled for this component yet because Apisix is currently not installed together with Rampart. 
- **image**
  - **repository**: tag is the image URL
  - **ports**: a list of ports you want to expose from this image. Each port is configured as following:
    - **name**: name of this port
    - **port**: port number, must be an integer
    - **ingressPath**: optional path of the endpoint seen from outside of the cluster
    - **ingressHost**: optional host name of the endpoint
  - **command**: a list of strings composing the command used to run the image
  - **args**: a list of strings composing the arguments to be appended to the command
  - **env**: environment variables to be passed into the container, in the format `{"name": <env_name>, "value":  <env_value>}`
- **imagePullSecrets**: A list of secrets used for pulling the job image, in the format `{"name": <secret_name>}`.
- **ingress**: when enabled, the service will become accessible from outside of the Kubernetes cluster. 
  - **enabled**: set to false to disable ingress
  - **pathPrefix**: use it to prepend a prefix to all the `ingressPath`s defined above. This prevents conflicted paths across different rampart graphs. For example, setting it to server will convert the paths to /server and /server/translate. The default pathPrefix is suggested by Rampart controller and is currently `<graph_namespace>/<graph_name>/<component_name>/`
